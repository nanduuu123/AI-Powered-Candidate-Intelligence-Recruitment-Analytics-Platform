from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


job_description = "Python SQL Machine Learning Power BI NLP"

candidate_resumes = [
    "Python SQL Power BI",
    "Java Cloud AWS",
    "Python NLP Machine Learning SQL"
]


vectorizer = TfidfVectorizer()

vectors = vectorizer.fit_transform([job_description] + candidate_resumes)

similarity_scores = cosine_similarity(vectors[0:1], vectors[1:]).flatten()


for index, score in enumerate(similarity_scores):
    print(f"Candidate {index + 1} Match Score: {round(score * 100, 2)}%")
