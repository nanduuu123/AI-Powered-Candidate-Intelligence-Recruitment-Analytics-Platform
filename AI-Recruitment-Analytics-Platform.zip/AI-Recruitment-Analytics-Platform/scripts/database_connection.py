from sqlalchemy import create_engine
import pandas as pd


username = 'root'
password = 'password'
host = 'localhost'
database = 'recruitment_db'


engine = create_engine(
    f'mysql+pymysql://{username}:{password}@{host}/{database}'
)


def insert_candidate_data(df, table_name):
    df.to_sql(table_name, con=engine, if_exists='replace', index=False)
    print("Data inserted successfully")


if __name__ == "__main__":
    sample_data = pd.DataFrame({
        'Candidate': ['Alice', 'Bob'],
        'Skill': ['Python', 'SQL']
    })

    insert_candidate_data(sample_data, 'candidate_table')
