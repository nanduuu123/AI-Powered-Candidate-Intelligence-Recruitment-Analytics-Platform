import pandas as pd


def preprocess_data(file_path):
    df = pd.read_csv(file_path)

    df = df.drop_duplicates()
    df = df.fillna('Not Available')

    return df


if __name__ == "__main__":
    cleaned_df = preprocess_data("../data/candidate_data.csv")
    print(cleaned_df.head())
