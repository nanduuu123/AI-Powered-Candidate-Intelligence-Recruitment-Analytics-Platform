import pdfplumber
import re


def extract_text_from_pdf(pdf_path):
    text = ""

    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            text += page.extract_text()

    return text


def extract_skills(text):
    skills_list = [
        'python', 'sql', 'machine learning', 'power bi',
        'excel', 'nlp', 'data analysis', 'tableau'
    ]

    extracted_skills = []

    for skill in skills_list:
        if re.search(skill, text.lower()):
            extracted_skills.append(skill)

    return extracted_skills


if __name__ == "__main__":
    print("Resume parser module ready.")
