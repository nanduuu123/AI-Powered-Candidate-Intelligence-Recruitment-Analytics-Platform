import streamlit as st


st.title("AI Recruitment Analytics Platform")

st.subheader("Candidate Ranking Dashboard")


candidate_scores = {
    'Candidate A': 92,
    'Candidate B': 85,
    'Candidate C': 78
}


for candidate, score in candidate_scores.items():
    st.write(f"{candidate}: {score}% Match")


uploaded_file = st.file_uploader("Upload Resume", type=['pdf'])

if uploaded_file:
    st.success("Resume Uploaded Successfully")
